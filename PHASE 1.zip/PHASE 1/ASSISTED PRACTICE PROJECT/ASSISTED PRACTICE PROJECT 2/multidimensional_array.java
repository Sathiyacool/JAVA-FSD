package Assistedpracticeproject;

public class multidimensional_array {

	public static void main(String[] args) {

    int B[][]= {{1,2,3,4},{5,6,7}};
    System.out.println("length of row 1 :"+B[0].length);
    System.out.println("length of row 2 :"+B[1].length);
	}

}
