package Assistedpracticeproject;

public class onedimension_array {

	public static void main(String[] args) {
		int A[]= {100,200,300,400,500};
		for(int i=0;i<5;i++)
		{
			System.out.println("The elements of an array A:"+A[i]);
		}

	}

}
